<?php
namespace beGateway;

class Payment extends Authorization {
}
?>
